﻿namespace Reminder.Storage
{
	public enum ReminderItemStatus
	{
		Undefied = 0,
		Created,
		Ready,
		Sent,
		Failed
	}
}
