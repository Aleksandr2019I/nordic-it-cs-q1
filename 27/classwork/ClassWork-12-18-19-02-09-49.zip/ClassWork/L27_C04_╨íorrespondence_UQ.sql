
-- проверка на уникальность одного поля
-- ALTER TABLE City DROP CONSTRAINT UQ_City_Name;
ALTER TABLE City
    ADD CONSTRAINT UQ_City_Name UNIQUE (Name);