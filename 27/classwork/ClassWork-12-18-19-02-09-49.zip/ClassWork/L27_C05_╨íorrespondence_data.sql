
INSERT INTO City (Id, [Name])
	VALUES (1, 'Москва'),
           (2, 'Санкт-Петербург');

INSERT INTO [Address] (Id, CityId, [Address])
	VALUES (1, 1, 'ул. Большая Садовая, д. 10'),
           (2, 2, 'ул. Сенная, д. 30');

INSERT INTO Position (Id, [Name])
    VALUES (1, 'Директор'),
           (2, 'Управляющий'),
           (3, 'Разработчик'),
           (4, 'Тестировщик'),
           (5, 'Менеджер');

INSERT INTO DocumentType (Id, [Name])
    VALUES (1, 'Книга'),
           (2, 'Отчет'),
           (3, 'Документация');

INSERT INTO Document (Id, TypeId, [Name], Pages)
    VALUES (1, 1, 'Война и мир, т.1', 666);

INSERT INTO Contractor (Id, Fullname, AddressId, PositionId)
    VALUES (1, 'Иванов И.И', 1, 1),
           (2, 'Петров П.П', 2, 2);

INSERT INTO DocumentStatus (Id, SenderId, ReceiverId, DocumentId, [Status], [DateTime])
    VALUES (1, 1, 2, 1, 'Отправлен', '2019.12.12T14:00:00'),
           (2, 1, 2, 1, 'Получен', '2019.12.12T14:00:00');