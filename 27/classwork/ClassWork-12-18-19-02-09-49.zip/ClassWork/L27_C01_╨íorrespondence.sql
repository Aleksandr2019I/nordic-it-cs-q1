
-- Документ
-- DROP TABLE [Document];
CREATE TABLE Document (
	Id INT NOT NULL,
    TypeId INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
	Pages INT NOT NULL
);
GO

-- Тип документа
-- DROP TABLE [DocumentType];
CREATE TABLE DocumentType (
    Id INT NOT NULL,
    [Name] VARCHAR(50) NOT NULL
);
GO

-- Адрес
-- DROP TABLE [Address];
CREATE TABLE [Address] (
	Id INT NOT NULL,
	CityId INT NOT NULL,
	[Address] VARCHAR(250) NOT NULL,
);
GO

-- Город
-- DROP TABLE [City];
CREATE TABLE City (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
);
GO

-- Контрагент
-- DROP TABLE Сontractor;
CREATE TABLE Сontractor (
	Id INT NOT NULL,
	Fullname VARCHAR(250) NOT NULL,
	PositionId INT NOT NULL,
    AddressId INT NOT NULL,
);
GO

-- Позиция
-- DROP TABLE Position;
CREATE TABLE Position (
	Id INT NOT NULL,
	[Name] VARCHAR(50) NOT NULL,
);
GO

-- Статус
-- DROP TABLE DocumentStatus;
CREATE TABLE DocumentStatus (
    Id INT NOT NULL,
    SenderId INT NOT NULL,
	ReceiverId INT NOT NULL,
	DocumentId INT NOT NULL,
	[Status] NVARCHAR(50),
	[DateTime] DATETIMEOFFSET NOT NULL,
);
GO
