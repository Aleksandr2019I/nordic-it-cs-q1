
-- Внешние ключи

-- ALTER TABLE Address DROP CONSTRAINT FK_Address_CityId;
ALTER TABLE Document
    ADD CONSTRAINT FK_Document_TypeId FOREIGN KEY (TypeId)
        REFERENCES DocumentType(Id)
            ON DELETE CASCADE
            ON UPDATE CASCADE
GO
-- ALTER TABLE Address DROP CONSTRAINT FK_Address_CityId;
ALTER TABLE [Address]
    ADD CONSTRAINT FK_Address_CityId FOREIGN KEY (CityId)
        REFERENCES City(Id)
            ON DELETE CASCADE
            ON UPDATE CASCADE
GO
-- ALTER TABLE Contractor DROP CONSTRAINT FK_Contractor_PositionId;
ALTER TABLE [Contractor]
    ADD CONSTRAINT FK_Contractor_PositionId FOREIGN KEY (PositionId)
        REFERENCES Position(Id)
            ON DELETE CASCADE
            ON UPDATE CASCADE
GO
-- ALTER TABLE Contractor DROP CONSTRAINT FK_Contractor_AddressId;
ALTER TABLE [Contractor]
    ADD CONSTRAINT FK_Contractor_AddressId FOREIGN KEY (AddressId)
        REFERENCES [Address](Id)
            ON DELETE CASCADE
            ON UPDATE CASCADE
GO
-- ALTER TABLE DocumentStatus DROP CONSTRAINT FK_DocumentStatus_DocumentId;
ALTER TABLE DocumentStatus
    ADD CONSTRAINT FK_DocumentStatus_DocumentId FOREIGN KEY (DocumentId)
        REFERENCES Document(Id)
            ON DELETE CASCADE
            ON UPDATE CASCADE
GO
-- ALTER TABLE DocumentStatus DROP CONSTRAINT FK_DocumentStatus_SenderId;
ALTER TABLE DocumentStatus
    ADD CONSTRAINT FK_DocumentStatus_SenderId FOREIGN KEY (SenderId)
	    REFERENCES Contractor(Id)
            ON UPDATE CASCADE
            ON DELETE NO ACTION
GO
-- ALTER TABLE DocumentStatus DROP CONSTRAINT FK_DocumentStatus_ReceierId;
ALTER TABLE DocumentStatus
    ADD CONSTRAINT FK_DocumentStatus_ReceierId FOREIGN KEY (ReceiverId)
        REFERENCES Contractor(Id)
            ON UPDATE NO ACTION
            ON DELETE NO ACTION
GO