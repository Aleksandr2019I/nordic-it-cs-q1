using System;

class Program
{
	static void Main()
	{
		int a;					// declaring
		a = 12;					// assigning the value
		Console.WriteLine(a);	// 12

		int b = 13;				// declaring and assigning the value
		Console.WriteLine(b);	// 13
	}
}
