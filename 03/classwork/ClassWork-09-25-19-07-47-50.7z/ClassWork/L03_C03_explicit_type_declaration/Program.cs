class Program
{
	static void Main()
	{
		// Exlicit type declaration
		int population = 66_000_000;
		double weight = 25;
		float height = 1.88F;
		decimal price = 4.99M;
		string fruit = "Apples";
		char letter = 'Z';
		bool happy = true;
	}
}