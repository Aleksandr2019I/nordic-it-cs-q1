﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using NUnit.Framework;

namespace Reminder.Storage.SqlServer.Tests
{
	public class ReminderStorageCreator
	{
		private readonly string _connectionString;

		public ReminderStorageCreator(string connectionString)
		{
			_connectionString = connectionString;
		}

		public void CreateTables()
		{
			ExecuteScript(Sql.CreateContactTable);
			ExecuteScript(Sql.CreateReminderItemStatusTable);
			ExecuteScript(Sql.InsertReminderItemStatusLines);
			ExecuteScript(Sql.CreateReminderItemTable);
		}

		public void CreateProcedures()
		{
			ExecuteScript(Sql.AddReminderItem);
		}

		public void DropProcedures()
		{
			ExecuteScript("DROP PROCEDURE IF EXISTS [sp_AddReminderItem];");
		}

		public void DropTables()
		{
			ExecuteScript("DROP TABLE IF EXISTS [ReminderItem];");
			ExecuteScript("DROP TABLE IF EXISTS [ReminderItemStatus];");
			ExecuteScript("DROP TABLE IF EXISTS [Contact];");
		}

		private void ExecuteScript(string script)
		{
			using var connection = new SqlConnection(_connectionString);
			connection.Open();

			using var command = connection.CreateCommand();
			command.CommandType = CommandType.Text;
			command.CommandText = script;
			command.ExecuteNonQuery();
		}
	}

	public class ReminderStorageTests
	{
		public const string ConnectionString = "Server=tcp:shadow-art.database.windows.net,1433;Initial Catalog=reminder; Persist Security Info=False;User ID=app_testing@shadow-art;Password=XCrzJjTRqX43uzaEpJNj;Encrypt=True;";
		public ReminderStorageCreator Creator { get; } =
			new ReminderStorageCreator(ConnectionString);

		[OneTimeSetUp]
		public void Setup()
		{
			Creator.CreateTables();
			Creator.CreateProcedures();
		}

		[OneTimeTearDown]
		public void Teardown()
		{
			//Creator.DropProcedures();
			//Creator.DropTables();
		}

		[Test]
		public void Test()
		{
			// Arrange
			var item = new ReminderItem(Guid.NewGuid(), "CONTACT", "Message", DateTimeOffset.UtcNow);
			var storage = new ReminderStorage(ConnectionString);

			// Act
			storage.Add(item);

			// Assert
			var result = storage.FindById(item.Id);
			Assert.AreEqual(item.Id, result.Id);
		}
	}
}
