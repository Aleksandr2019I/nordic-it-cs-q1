﻿using System.IO;
using Microsoft.Extensions.FileProviders;

namespace Reminder.Storage.SqlServer
{
	public static class Sql
	{
		public static string CreateContactTable =>
			ReadScript(nameof(CreateContactTable));

		public static string CreateReminderItemStatusTable =>
			ReadScript(nameof(CreateReminderItemStatusTable));

		public static string CreateReminderItemTable =>
			ReadScript(nameof(CreateReminderItemTable));

		public static string InsertReminderItemStatusLines =>
			ReadScript(nameof(InsertReminderItemStatusLines));

		public static string AddReminderItem =>
			ReadScript(nameof(AddReminderItem));

		private static string ReadScript(string name)
		{
			var provider = new EmbeddedFileProvider(typeof(Sql).Assembly);
			var info = provider.GetFileInfo($"Scripts\\{name}.sql");

			using var stream = info.CreateReadStream();
			using var reader = new StreamReader(stream);
			return reader.ReadToEnd();
		}
	}
}
