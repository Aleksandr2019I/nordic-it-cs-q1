﻿namespace L13_C06_interface.Interfaces
{
	public interface ICaller
	{
		void Call(string phoneNumber);
	}
}
