﻿namespace L13_C06_interface.Interfaces
{
	public interface IRestartable
	{
		void Restart();
	}
}
