﻿namespace L13_C06_interface.Interfaces
{
	public interface IMusicPlayer
	{
		string MusicSource { get; set; }

		void PlayMusic();
	}
}
