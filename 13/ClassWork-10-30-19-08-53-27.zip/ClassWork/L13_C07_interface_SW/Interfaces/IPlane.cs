namespace L13_C07_interface_SW.Interfaces
{
	interface IPlane
	{
		byte EnginesCount { get; }
	}
}
