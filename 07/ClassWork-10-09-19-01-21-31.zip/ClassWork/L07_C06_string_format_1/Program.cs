using System;

namespace L07_C06_string_format_1
{
	class Program
	{
		static void Main()
		{
			var i = 15.0;
			var j = Math.PI;
			var s = string.Format(
				"{0:0.###} divided by {1:0.###} equals to {2:0.###}",
				i,
				j,
				i / j);
			Console.WriteLine(s);
		}
	}
}