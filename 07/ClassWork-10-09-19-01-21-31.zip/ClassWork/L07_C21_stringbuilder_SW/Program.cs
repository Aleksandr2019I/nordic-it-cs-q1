using System;
using System.Text;

namespace L07_C21_stringbuilder_SW
{
	class Program
	{
		static void Main()
		{
			var text = "   lorem    ipsum    dolor      sit   amet  ";

			Console.WriteLine($"Original message: {text}");
			Console.WriteLine($"The result of first task is:{NormalizeAndUppercase(text, 1)}");
			Console.WriteLine($"The result of second task is:{TruncateTo(text, 4)}");
		}

		static string NormalizeAndUppercase(string text, int target)
		{
			var result = new StringBuilder();
			for (int i = 0, p = 0, word = -1; i < text.Length; p = i++)
			{
				var current = text[i];
				var previous = text[p];

				if (char.IsLetter(current) &&
					char.IsWhiteSpace(previous))
				{
					word++;
				}

				if (char.IsLetter(current))
				{
					result.Append(word == target ? char.ToUpper(current) : current);
				}

				if (char.IsWhiteSpace(current) &&
					char.IsLetter(previous))
				{
					result.Append(' ');
				}
			}
			return result.ToString();
		}

		static string TruncateTo(string text, int target)
		{
			var result = new StringBuilder();
			for (int i = 0, p = 0, word = -1; i < text.Length; p = i++)
			{
				var current = text[i];
				var previous = text[p];

				if (char.IsLetter(current) &&
					char.IsWhiteSpace(previous))
				{
					word++;
				}

				if ((char.IsLetter(current) && word < target) ||
					(char.IsWhiteSpace(current) && word < target - 1))
				{
					result.Append(current);
				}
			}
			return result.ToString();
		}
	}
}
