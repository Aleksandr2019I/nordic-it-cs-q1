using System;

namespace L07_C09_string_interpolation
{
	class Program
	{
		static void Main()
		{
			var i = 15.0;
			var j = Math.PI;
			var s = $"{i} divided by {j:0.##} equals to {i / j:0.##}";
			Console.WriteLine(s); // 15 divided by 3.14 equals to 4.77

			var now = DateTime.Now;
			var result = $"Now is {now:dd.MM.yyyy HH:mm}";
			Console.WriteLine(result);
		}
	}
}