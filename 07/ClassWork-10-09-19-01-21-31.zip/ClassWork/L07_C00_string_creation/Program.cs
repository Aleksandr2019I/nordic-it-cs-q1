﻿using System;

namespace L07_C00_string_creation
{
	class Program
	{
		static void Main(string[] args)
		{
			// Empty reference, value is equal to null
			string str;

			// reference type, created via new operator
			var first = "hello world";              // assigning a constant value
			var second = new string("hello world"); // conversion from string to string via new operator
			var third = new string('f', 10);        // fff
			var fourth = new string(new[] { 'a', 'b', 'c' }); // abc

			Console.WriteLine(first);
			Console.WriteLine(second);
			Console.WriteLine(third);
			Console.WriteLine(fourth);

			var abc = "\u0061\u0062\u0063"; // abc
			var abctoo = "abc";

			Console.WriteLine(abc);
			Console.WriteLine(abctoo);
		}
	}
}