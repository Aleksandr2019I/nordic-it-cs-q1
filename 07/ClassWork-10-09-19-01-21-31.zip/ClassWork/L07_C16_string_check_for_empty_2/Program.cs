using System;

namespace L07_C16_string_check_for_empty_2
{
	class Program
	{
		static void Main()
		{
			string @null = default;

			Console.WriteLine(string.IsNullOrWhiteSpace("   \t   "));   // true
			Console.WriteLine(string.IsNullOrEmpty(""));                // true
			Console.WriteLine(string.IsNullOrEmpty(null));              // true
			Console.WriteLine(@null == null);
			Console.WriteLine(@null is null);
			Console.WriteLine(string.Equals(@null, null));
		}
	}
}