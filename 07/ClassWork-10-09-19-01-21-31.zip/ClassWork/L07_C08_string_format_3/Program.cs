using System;

namespace L07_C08_string_format_3
{
	class Program
	{
		static void Main()
		{
			var now = DateTime.Now;
			var result = String.Format("Now is {0:dd.MM.yyyy HH:mm}", now);
			Console.WriteLine(result);
		}
	}
}