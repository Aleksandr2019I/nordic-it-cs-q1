using System;

namespace L07_C18_string_join_2
{
	class Program
	{
		static void Main()
		{
			var test = "my test string";

			// split strings into string array
			var words = test.Split(' ');

			// rebuild string taking the first and the third words only
			var result = string.Join("_", words[0], words[2]);

			Console.WriteLine(result);
			// my_string
		}
	}
}
