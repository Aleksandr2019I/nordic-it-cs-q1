using System;

namespace L07_C13_string_toupper
{
	class Program
	{
		static void Main()
		{
			Console.Write("Enter cardholder name: ");
			var cardholder = Console.ReadLine();

			Console.WriteLine($"Valid cardholder name: {cardholder.ToUpper()}");

			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();
		}
	}
}