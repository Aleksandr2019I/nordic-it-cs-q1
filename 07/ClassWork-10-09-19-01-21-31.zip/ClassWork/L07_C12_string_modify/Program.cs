using System;

namespace L07_C12_string_modify
{
	class Program
	{
		static void Main()
		{
			var words = "my test string";
			Console.WriteLine(words.Replace("test", "best"));   // my best string
			Console.WriteLine(words.Substring(8, 3));           // str

			foreach (var word in words.Split(' '))
			{
				Console.WriteLine(word);
			}

			// my
			// test
			// string
		}
	}
}