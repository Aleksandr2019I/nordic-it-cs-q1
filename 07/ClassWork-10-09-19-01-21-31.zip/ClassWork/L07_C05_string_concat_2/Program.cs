using System;

namespace L07_C05_string_concat_2
{
	class Program
	{
		static void Main()
		{
			var i = 15;
			var j = 3;
			var result1 = i + " divided by " + j + " equals to " + i / j;
			Console.WriteLine(result1);

			var now = DateTime.Now;
			var result2 = String.Format("Now is {0:dd.MM.yyyy HH:mm}", now);
			Console.WriteLine(result2);
		}
	}
}