using System;

namespace L07_C10_string_building_SW
{
	class Program
	{
		static void Main()
		{
			Console.WriteLine("Enter two real numbers to multiply them:");
			var d1 = double.Parse(Console.ReadLine());
			var d2 = double.Parse(Console.ReadLine());
			Console.WriteLine(d1 + " * " + d2 + " = " + d1 * d2);
			Console.WriteLine("{0:0.##} + {1:0.##} = {2:0.##}", d1, d2, d1 + d2);
			Console.WriteLine($"{d1:#.##} - {d2:#.##} = {(d1 - d2):#.##}");
			Console.WriteLine($"{d1:0.##} - {d2:0.##} = {(d1 - d2):0.##}");
		}
	}
}