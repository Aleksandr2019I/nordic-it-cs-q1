using System;

namespace L07_C17_string_join_1
{
	class Program
	{
		static void Main()
		{
			var test = "my tESt string";
			var words = test.Split(' ');

			Console.WriteLine(string.Join(" & ", words));
			// my & test & string

			// Create from string Pascal-casing and Camel-casing variable names
			var pascalCasingName = new string[words.Length];
			var camelCasingName = new string[words.Length];

			for (var i = 0; i < words.Length; i++)
			{
				string word = words[i];

				pascalCasingName[i] = char.ToUpper(word[0]) + word.Substring(1).ToLower();
				camelCasingName[i] = i == 0
					? word.ToLower()
					: char.ToUpper(word[0]) + word.Substring(1).ToLower();
			}

			Console.WriteLine(string.Join(null, pascalCasingName));
			Console.WriteLine(string.Join(null, camelCasingName));
		}
	}
}