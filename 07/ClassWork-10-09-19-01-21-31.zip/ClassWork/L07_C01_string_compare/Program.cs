using System;

namespace L07_C01_string_compare
{
	class Program
	{
		static void Main()
		{
			var a = "test±";
			var b = "T\u0045st\u00b1";

			Console.WriteLine(a);
			Console.WriteLine(b);

			WriteStringCharCodes(a);
			WriteStringCharCodes(b);

			Console.WriteLine(a == b);      // false
			Console.WriteLine(a.Equals(b)); // false
			Console.WriteLine(a.Equals(b, StringComparison.InvariantCultureIgnoreCase)); // true
		}

		static void WriteStringCharCodes(string input)
		{
			foreach (var letter in input)
			{
				Console.Write((int)letter + " ");
			}

			Console.Write("\n");
		}
	}
}