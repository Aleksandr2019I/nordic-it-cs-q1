using System;

namespace L07_C14_string_trim
{
	class Program
	{
		static void Main()
		{
			var sequence = " \t my test string \t ";

			Console.WriteLine(sequence.Trim());
			Console.WriteLine(sequence.TrimStart());
			Console.WriteLine(sequence.TrimEnd());

			// my test string		 < no spaces around
			// my test string 	 < spaces at the end
			// 	 my test string	 < spaces at the beginning
		}
	}
}