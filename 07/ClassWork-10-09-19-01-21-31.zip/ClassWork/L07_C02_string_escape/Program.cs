using System;

namespace L07_C02_string_escape
{
	class Program
	{
		static void Main()
		{
			var test = "a\tb\nc";
			Console.WriteLine(test);
			// a  b
			// c
		}
	}
}