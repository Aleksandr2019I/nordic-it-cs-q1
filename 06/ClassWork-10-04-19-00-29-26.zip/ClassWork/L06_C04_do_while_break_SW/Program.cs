using System;

namespace L06_C04_do_while_break_SW
{
	class Program
	{
		static void Main()
		{
			do
			{
				Console.Write("Enter text string (or \"exit\" to finish): ");
				var input = Console.ReadLine();
				if (input == "exit")
				{
					break;
				}
			}
			while (true);

			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();
		}
	}
}
