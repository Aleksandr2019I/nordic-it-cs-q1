using System;

namespace L06_C10_while_SW
{
	class Program
	{
		static void Main()
		{
			var array = new[] { 7, 43, 23, 32, 34 };
			var counter = 0;
			var sum = 0;

			while (counter < array.Length)
			{
				sum += array[counter];
				Console.WriteLine(sum);

				counter++;
			}

			Console.WriteLine($"The sum is {sum}");
			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();
		}
	}
}
