﻿using System;

namespace L06_C05_do_while_continue
{
	class Program
	{
		static void Main()
		{
			Console.WriteLine("Program reads integer values and stops, when sum exceeds 100. ");

			var sum = 0;
			do
			{
				try
				{
					Console.Write("Enter the integer value: ");
					sum += int.Parse(Console.ReadLine());
				}
				catch (FormatException)
				{
					Console.WriteLine("You entered wrong value! Please try again:");
					continue;
				}

				Console.WriteLine($"Calculated value is: {sum}");
			}
			while (sum < 100);

			Console.WriteLine($"The sum is {sum}. Press any key to exit...");
			Console.ReadKey();
		}
	}
}