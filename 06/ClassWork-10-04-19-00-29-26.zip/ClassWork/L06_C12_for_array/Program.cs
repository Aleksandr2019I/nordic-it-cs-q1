﻿using System;

namespace L06_C12_for_array
{
	class Program
	{
		static void Main()
		{
			Console.Write("Enter the array length: ");
			var length = int.Parse(Console.ReadLine());
			var array = new int[length];

			for (int i = 0; i < array.Length; i++)
			{
				Console.Write($"Enter the #{i + 1} number of array: ");
				array[i] = int.Parse(Console.ReadLine());
			}

			Console.WriteLine($"The entered values are: {string.Join(", ", array)}");
			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();
		}
	}
}