using System;

namespace L06_C14_for_in_for_SW
{
	class Program
	{
		static void Main()
		{
			// todo: total average value can ba calculated in one line, actually
			// Weekly school marks
			var marks = new[]
			{
				new [] { 2, 3, 3, 2, 3 }, // Monday (it was a good weekend :)
				new [] { 2, 4, 5, 3 },    // Tuesday (anyway better than Monday)
				null,                     // Wednesday (felt sick, stayed at home :( )
				new [] { 5, 5, 5, 5 },    // Thursday (God mode :)
				new [] { 4 }              // Friday (a very short day)
			};

			var total = 0.0;
			var totalCount = 0;

			for (var day = 0; day < marks.Length; day++)
			{
				if (marks[day] == null)
				{
					Console.WriteLine($"The average mark for day {day} is N/A");
					continue;
				}

				var sum = 0.0;
				for (var mark = 0; mark < marks[day].Length; mark++)
				{
					sum += marks[day][mark];
				}

				Console.WriteLine("The average mark for day {0} is {1:0.0}",
					day,
					sum / marks[day].Length);

				total += sum;
				totalCount += marks[day].Length;
			}

			Console.WriteLine("The average mark for all the week is {0:0.0}",
				total / totalCount);

			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();
		}
	}
}
