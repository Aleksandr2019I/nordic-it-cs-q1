using System;

namespace L06_C02_do_while_SW
{
	class Program
	{
		static void Main()
		{
			string input;
			do
			{
				Console.Write("Enter text string (or \"exit\" to finish): ");
				input = Console.ReadLine();
			}
			while (!string.Equals(input, "exit", StringComparison.OrdinalIgnoreCase));

			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();
		}
	}
}
