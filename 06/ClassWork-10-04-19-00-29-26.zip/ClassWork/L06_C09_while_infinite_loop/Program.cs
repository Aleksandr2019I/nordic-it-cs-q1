﻿using System;

namespace L06_C09_while_infinite_loop
{
	class Program
	{
		static void Main()
		{
			Console.WriteLine("Enter 5 integer values to summarize them:");

			var sum = 0;
			var number = 0;
			while (true) // infinite cycle
			{
				if (number > 4)
				{
					break;
				}

				try
				{
					sum += int.Parse(Console.ReadLine());
				}
				catch (FormatException)
				{
					Console.WriteLine($"Aborting! only {number} values were summarized!");
					break;
				}

				number++;
			}
			Console.WriteLine($"The sum is {sum}. Press any key to exit...");
			Console.ReadKey();
		}
	}
}