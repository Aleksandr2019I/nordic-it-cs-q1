﻿using System;

namespace L06_C07_while
{
	class Program
	{
		static void Main()
		{
			Console.WriteLine("Enter integer values.");
			Console.WriteLine("When Sum exceeds 100 program will be finished:");

			var sum = 0;
			while (sum < 100)   // now condition checks before the cycling
			{
				try
				{
					sum += int.Parse(Console.ReadLine());
				}
				catch (FormatException)
				{
					Console.WriteLine("You entered wrong value! Please try again:");
					continue;   // return to the beginning of the cycle!
				}
			}

			Console.WriteLine($"The sum is {sum}. Press any key to exit...");
			Console.ReadKey();
		}
	}
}