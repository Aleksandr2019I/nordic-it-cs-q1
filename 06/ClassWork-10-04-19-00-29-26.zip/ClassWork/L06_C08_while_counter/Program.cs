﻿using System;

namespace L06_C08_while_counter
{
	class Program
	{
		static void Main()
		{
			Console.WriteLine("Enter 5 integer values to summarize them:");

			var sum = 0;
			var counter = 0;    // variable to calculate the number of entered values
			while (counter < 5) // checking that number of entered values less than 5
			{
				try
				{
					sum += int.Parse(Console.ReadLine());
				}
				catch (FormatException)
				{
					Console.WriteLine($"Aborting! only {counter} values were summarized!");
					break;
				}
				counter++;
			}
			Console.WriteLine($"The sum is {sum}. Press any key to exit...");
			Console.ReadKey();
		}
	}
}