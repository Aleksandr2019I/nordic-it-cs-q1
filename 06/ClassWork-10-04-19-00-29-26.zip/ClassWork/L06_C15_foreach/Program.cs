﻿using System;

namespace L06_C15_foreach
{
	class Program
	{
		static void Main()
		{
			Console.WriteLine("Enter 5 integer values:");
			var numbers = new int[5];

			for (var i = 0; i < 5; i++)
			{
				numbers[i] = int.Parse(Console.ReadLine());
			}

			foreach (var number in numbers)
			{
				Console.WriteLine($"{number}^2 = {number * number}");
			}

			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();
		}
	}
}