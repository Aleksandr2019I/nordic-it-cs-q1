﻿using System;

namespace L06_C11_for
{
	class Program
	{
		static void Main()
		{
			// Common structure
			// for (initializer; condition; iterator)
			//    cycle_body

			for (var i = 0; i < 5; i++)
			{
				Console.WriteLine(i);
			}

			// The same as above
			var counter = 0;
			while (counter < 5)
			{
				Console.WriteLine(counter++);
			}

			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();

			// Output:
			// 0
			// 1
			// 2
			// 3
			// 4
		}
	}
}