-- Удаление существующей хранимой процедуры
DROP PROCEDURE IF EXISTS [sp_GetOrCreateCategoryId]
GO

-- SP будет вставлять новую категорию в таблицу или возвращать существующую и возвращать нам GUID этой категории
-- void sp_GetOrCreateCategoryId(string p_category, out Guid p_categoryId);
CREATE PROCEDURE sp_GetOrCreateCategoryId (
    @p_category AS VARCHAR(250),
    @p_categoryId AS UNIQUEIDENTIFIER OUTPUT
)
AS
BEGIN
    -- отключене сообщение о количестве изменённых записей
    -- (best practice)
    SET NOCOUNT ON
    DECLARE @categoryId UNIQUEIDENTIFIER = fn_FindCategory(@p_category);

    IF @categoryId IS NULL
    BEGIN
        SET @categoryId = NEWID()

        INSERT INTO Category([Id], [Name])
        VALUES (@categoryId, @p_category);
    END

    SET @p_categoryId = @categoryId;
END
GO

-- Переменная для сохранения результата
DECLARE @categoryId UNIQUEIDENTIFIER;

-- Вызов процедуры и сохранение результата в @categoryId
EXECUTE sp_GetOrCreateCategoryId
    @p_category  = 'Mobile',
    @p_categoryId = @categoryId OUTPUT;
SELECT @categoryId AS Id;

-- Аналогичная конструкция
EXEC sp_GetOrCreateCategoryId
    @p_category  = 'Mobile',
    @p_categoryId = @categoryId OUTPUT;
GO
--
--
DROP PROCEDURE IF EXISTS [sp_CreateProduct]
GO
--
CREATE PROCEDURE sp_CreateProduct (
	@p_Category AS VARCHAR(250),
	@p_Product AS NVARCHAR(250),
	@p_ProductId AS UNIQUEIDENTIFIER OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON

	-- объявляем переменную идентификатора категории
	DECLARE @productId UNIQUEIDENTIFIER = NEWID();
    DECLARE @categoryId UNIQUEIDENTIFIER;

    EXECUTE sp_GetOrCreateCategoryId
        @p_Category = @p_category,
        @p_CategoryId = @categoryId OUTPUT;

    INSERT INTO Product ([Id], [CategoryId], [Name])
        VALUES (@productId, @categoryId, @p_Product);

    SET @p_ProductId = @productId;
END
GO

-- проверяем, как работает наша процедура на данных для успешной вставки
-- когда не нужно создавать новую категорию
DECLARE @productId UNIQUEIDENTIFIER;
EXECUTE sp_CreateProduct
    @p_Category = 'Mobile',
    @p_Product = 'Epson 200',
    @p_ProductId = @productId;
SELECT @productId AS ProductId;
SELECT * FROM Category;
SELECT * FROM Product;
GO
