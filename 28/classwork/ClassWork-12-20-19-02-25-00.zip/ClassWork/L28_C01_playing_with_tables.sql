﻿
-- Создаём таблицу с GUID-полем
-- DROP TABLE dbo.[Category]
CREATE TABLE [Category] (
	Id UNIQUEIDENTIFIER NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
	CONSTRAINT PK_Category PRIMARY KEY CLUSTERED (Id),
	CONSTRAINT UQ_Category_Name UNIQUE ([Name])
);
GO
CREATE TABLE Product (
	Id UNIQUEIDENTIFIER NOT NULL ,
	CategoryId UNIQUEIDENTIFIER NOT NULL,
	[Name] NVARCHAR(250) NOT NULL,
	CONSTRAINT PK_Product PRIMARY KEY CLUSTERED (Id),
	CONSTRAINT UQ_Goods_Name UNIQUE ([Name])
);
GO
ALTER TABLE Product
	ADD CONSTRAINT FK_Product_CategoryId FOREIGN KEY (CategoryId)
		REFERENCES Category(Id)
            ON UPDATE NO ACTION
            ON DELETE NO ACTION;
GO

-- Вставка значений
INSERT INTO [Category] (Id, [Name])
    VALUES (NEWID(), 'Mobile Phones'),
           (NEWID(), 'TV'),
           (NEWID(), 'Laptop'),
           (NEWID(), 'PC'),
           (NEWID(), 'Video player');

-- Смотрим результат
SELECT * FROM [Category]
GO

-- Изменяем значение поля
UPDATE [Category]
	SET [Name] = 'Mobile Phone'
WHERE [Name] = 'Mobile Phones'

-- Смотрим результат
SELECT * FROM [Category]
GO

-- Попытка повторной вставки значений завершится с ошибкой
INSERT INTO [Category] (Id, [Name])
    VALUES (NEWID(), 'TV')

-- Сортировка по возрастанию / убыванию
SELECT
    *
FROM [Category]
ORDER BY [Name] ASC;

SELECT
    *
FROM [Category]
ORDER BY [Name] DESC;

-- Выбрка первых N записей (не имеет смысла без сортировки)
SELECT TOP 3
    *
FROM [Category]
ORDER BY [Name] DESC;

-- Выборка записей через OFFSET-FETCH
SELECT
    *
FROM [Category]
ORDER BY [Name] DESC
OFFSET 1 ROW
FETCH NEXT 4 ROW ONLY;
GO

-- Поиск с использованием LIKE
SELECT * FROM [Category] WHERE [Name] LIKE 'Mobile%';  -- EndsWith
SELECT * FROM [Category] WHERE [Name] LIKE '%Mobile';  -- StartsWith
SELECT * FROM [Category] WHERE [Name] LIKE '%Mobile%'; -- Contains

-- Сортировка с указанием правил сравнения (COLLATION)
-- Выборка всех поддерживаемых правил сравнения
SELECT name, description FROM sys.fn_helpcollations();

-- Сравнение с учетом регистра (Case Sensitive)
SELECT * FROM [Category] WHERE [Name] = 'laptop' COLLATE Latin1_General_CS_AS_KS_WS;

-- Сравнение без учета регистра (Case Insensitive)
SELECT * FROM [Category] WHERE [Name] = 'laptop' COLLATE Latin1_General_CI_AS_KS_WS;
GO

-- Полностью очищаем таблицу
-- DELETE FROM [Category];
-- TRUNCATE TABLE dbo.[Category];

-- Определяем переменную типа UNIQUEIDENTIFIER
DECLARE @guid AS UNIQUEIDENTIFIER;
GO

-- Обе конструкции крректны
DECLARE @guid UNIQUEIDENTIFIER;

-- Задаём переменной значение поля CategoryId
-- из таблицы Category где поле Name равно 'Mobile Phone'
SELECT @guid = Id
FROM Category AS C
WHERE C.[Name] = 'Mobile Phone';

-- Можем посмотреть значение этой переменной
PRINT @guid
GO

DECLARE @guid AS UNIQUEIDENTIFIER;
SELECT @guid = Id
FROM Category AS C
WHERE C.[Name] = 'NOT EXISTING CATEGORY';

-- При выводе увидим пустую строку, т.к. в @guid NULL
-- А далее, любая операция с NULL возвращает UNDEFINED
-- Поэтому получаем UNDEFINED
PRINT 'The value is ' + CONVERT(VARCHAR(36), @guid);

-- Функция COALESCE вернет первое значение, которое не NULL или не UNDEFINED
PRINT 'The value is ' + COALESCE(CONVERT(VARCHAR(36), @guid), 'NULL');
