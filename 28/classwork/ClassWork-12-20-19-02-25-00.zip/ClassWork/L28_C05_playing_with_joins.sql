
-- INNER JOIN
SELECT *
FROM Category
INNER JOIN Product
	ON Product.CategoryId = Category.Id

-- LEFT JOIN

-- выбрать все(!) категории и соответствующие им товары (если такие есть)
SELECT *
FROM Category AS C
LEFT JOIN Product AS G
	ON G.CategoryId = C.Id

-- выбрать такие категории у которых нет ни одного товары
SELECT *
FROM Category AS C
LEFT JOIN Product AS G
	ON G.CategoryId = C.Id
WHERE G.CategoryId IS NULL

-- RIGHT JOIN
-- поскольку у таблицы Product стоит внешний ключ на таблицу Category наш RIGHT JOIN
-- по факту вернёт то же самое, что и INNER JOIN
SELECT *
FROM Category AS C
RIGHT JOIN Product AS G
	ON G.CategoryId = C.Id

-- FULL JOIN
-- поскольку у таблицы Product стоит внешний ключ на таблицу Category наш FULL JOIN
-- по факту вернёт то же самое, что и LEFT JOIN
SELECT *
FROM Category AS C
FULL JOIN Product AS G
	ON G.CategoryId = C.Id
