-- Функции и Хранимые процедуры
-- Функция, которая
--  принимает категорию и возвращает идентификатор
--  выполняет поиск по  точному совпадению
--  если значения не найдено, выполняет поиск с помощью оператора LIKE и возврвщает певый результат
--  то в провтивном случае возвращается NULL

-- C# аналог
-- Guid fn_FindCategory(string p_category)
-- Функции всегда возвращают значения через Return и не доолжны изменять состояние БД

CREATE OR ALTER FUNCTION fn_FindCategory (
    @p_category NVARCHAR(250)
)
RETURNS UNIQUEIDENTIFIER
BEGIN
    DECLARE @categoryId UNIQUEIDENTIFIER;

    SELECT @categoryId = [Id]
        FROM [Category]
    WHERE [Name] = @p_category;

    IF @categoryId IS NULL
    BEGIN
        SELECT TOP 1
            @categoryId = [Id]
        FROM [Category]
        WHERE [Name] LIKE @p_category + '%'
        ORDER BY [Name];
    END

    RETURN @categoryId;
END;
GO

SELECT * FROM Category;
SELECT [dbo].fn_FindCategory('Computer');
SELECT [dbo].fn_FindCategory('Com');
SELECT [dbo].fn_FindCategory('NOT FOUND');