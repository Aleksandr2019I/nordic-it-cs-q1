CREATE DATABASE PostOffice;

USE PostOffice;
GO

CREATE TABLE PostalSending(
    SenderName      VARCHAR(50) NOT NULL,
    ReceiverName      VARCHAR(50) NOT NULL,
    DocumentTitle VARCHAR(50) NOT NULL,
    NumberOfPages  SMALLINT NOT NULL,
    SendingDate    DATETIME2 NOT NULL,
    ExpectedRecrivingDate DATETIME2 NOT NULL
);
SELECT * FROM PostalSending;

INSERT INTO PostalSending (SenderName,ReceiverName,DocumentTitle,NumberOfPages,SendingDate,ExpectedRecrivingDate)
VALUES ('Smirnov','Bush','Pismo1',10,'2019-12-12T11:00:10','2019-12-13T12:00:00'),
        ('Bushe','Smirnov','Pismo22',31,'2019-12-12T11:00:20','2019-12-13T12:00:30');

SELECT * FROM PostalSending;
DELETE FROM PostalSending WHERE SenderName = 'Smirnov';
SELECT * FROM PostalSending;
DROP TABLE PostalSending;
SELECT * FROM PostalSending;

USE master;
DROP DATABASE PostOffice;



