-- Объединения

-- Найти список товаров с ценой, количеством и стоимостью для заказа c ID = 22,
-- а также посчитать полную стоимость этого заказа
---
-- Сначала объединяем таблицы по связанным полям
SELECT *
FROM [Order] AS O
JOIN [OrderLine] AS OI
	ON OI.[OrderId] = O.[Id]
JOIN [Product] AS P
	ON P.[Id] = OI.[ProductId];

-- затем определяем выводимые поля и фильтр
SELECT
	P.[Name],
	P.[Price],
	OI.[Count],
	P.[Price] * OI.Count AS [SubTotal]
FROM [Order] AS O
JOIN [OrderLine] AS OI
	ON OI.[OrderId] = O.[Id]
JOIN [Product] AS P
	ON P.[Id] = OI.[ProductId]
WHERE O.[Id] = 22;

-- 2. Посчитать итоговую сумму товара
SELECT SUM(P.[Price] * OI.Count) AS [Total]
FROM [Order] AS O
JOIN [OrderLine] AS OI
	ON OI.[OrderId] = O.[Id]
JOIN [Product] AS P
	ON P.[Id] = OI.[ProductId]
WHERE O.[Id] = 22;