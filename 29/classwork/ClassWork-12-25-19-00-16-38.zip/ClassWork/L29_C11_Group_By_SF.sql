-- Написать запрос, возвращающий полную итоговую сумму, потраченную каждым клиентом
-- В формате
--  Идентификатор клиента
--  Имя клиента
--  Итоговая сумма

SELECT
    T.CustomerId AS CustomerId,
    C.Name AS CustomerName,
    SUM(T.Total) AS CustomerTotal
FROM (
    SELECT
        O.CustomerId,
        (1 - ISNULL(O.Discount, 0)) * SUM(OL.Count * P.Price) AS Total
    FROM [Order] AS O
    JOIN [OrderLine] AS OL
        ON O.Id = OL.OrderId
    JOIN [Product] AS P
        ON P.Id = OL.ProductId
    GROUP BY O.CustomerId, O.Discount
) AS T
JOIN [Customer] AS C
    ON C.Id = T.CustomerId
GROUP BY T.CustomerId, C.Name;

-- Добавить разбивку по годам и сортировку по имени, а зачем по году
SELECT
    T.CustomerId AS CustomerId,
    T.Year,
    C.Name AS CustomerName,
    SUM(T.Total) AS CustomerTotal
FROM (
    SELECT
        O.CustomerId,
        YEAR(O.OrderDate) AS [Year],
        (1 - ISNULL(O.Discount, 0)) * SUM(OL.Count * P.Price) AS Total
    FROM [Order] AS O
    JOIN [OrderLine] AS OL
        ON O.Id = OL.OrderId
    JOIN [Product] AS P
        ON P.Id = OL.ProductId
    GROUP BY O.CustomerId, YEAR(O.OrderDate), O.Discount
) AS T
JOIN [Customer] AS C
    ON C.Id = T.CustomerId
GROUP BY T.CustomerId, T.Year, C.Name
ORDER BY C.Name, T.Year DESC;