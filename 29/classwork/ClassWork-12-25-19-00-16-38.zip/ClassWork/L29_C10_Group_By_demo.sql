-- Группировки

-- Общее количество обработанных заказов
SELECT COUNT(*) FROM [Order] AS O

-- Количество обработанных заказов сгруппированных по годам
SELECT
    YEAR(O.[OrderDate]),
    COUNT(*)
FROM [Order] AS O
GROUP BY YEAR(O.[OrderDate])

-- ID и даты заказов с полной итоговой суммой заказа
SELECT
	O.[Id],
	O.[OrderDate],
	SUM(P.[Price] * OI.Count) AS [Total]
FROM [Order] AS O
INNER JOIN [OrderLine] AS OI
	ON OI.[OrderId] = O.[Id]
INNER JOIN [Product] AS P
	ON P.[Id] = OI.[ProductId]
GROUP BY O.[Id], O.[OrderDate]

-- Расчёт денег, потраченных Марией с учётом скидки к каждому товару
SELECT SUM(T.Total) FROM (
    SELECT
		(1 - ISNULL(O.Discount,0)) * SUM(P.[Price] * OI.Count) AS Total
	FROM [Order] AS O
	INNER JOIN [OrderLine] AS OI
		ON OI.[OrderId] = O.[Id]
	INNER JOIN [Product] AS P
		ON P.[Id] = OI.[ProductId]
	INNER JOIN [Customer] AS C
		ON C.[Id] = O.[CustomerId]
	WHERE C.[Name] = 'Мария'
	GROUP BY O.Discount
) AS T;