-- Объединения

-- Найти итоговую сумму, потраченную Марией
---
-- Сначала объединяем необходимые таблицы по связанным полям
SELECT *
FROM [Order] AS O
JOIN [OrderLine] AS OI
	ON OI.[OrderId] = O.[Id]
JOIN [Product] AS P
	ON P.[Id] = OI.[ProductId]
JOIN [Customer] AS C
	ON C.[Id] = O.[CustomerId];
--
-- затем определяем выводимые поля и фильтр
SELECT
    P.Price,
    OI.Count,
    SUM(P.[Price] * OI.Count) AS [Total]
FROM [Order] AS O
JOIN [OrderLine] AS OI
	ON OI.[OrderId] = O.[Id]
JOIN [Product] AS P
	ON P.[Id] = OI.[ProductId]
JOIN [Customer] AS C
	ON C.[Id] = O.[CustomerId]
WHERE C.[Name] = 'Мария';