using System;

namespace L09_C02_bubble_sort
{
	public class Program
	{
		static void Main()
		{
			var source = GenerateRandomArray();
			var destination = (int[])source.Clone();

			BubbleSort(destination);
			WriteArray("Initial state:", source);
			WriteArray("Sorted state:", destination);
			Console.ReadKey();
		}

		// функция создания массива для тестирования сортировки
		static int[] GenerateRandomArray()
		{
			const int length = 5;
			const int maxValue = 100;
			var arr = new int[length];

			var rnd = new Random();
			for (var i = 0; i < arr.Length; i++)
			{
				arr[i] = rnd.Next(maxValue);
			}

			return arr;
		}

		// функция вывода на экран элементов массива с названием состояния
		static void WriteArray(string message, int[] array)
		{
			Console.WriteLine(message);

			foreach (var item in array)
			{
				Console.WriteLine(item);
			}
		}

		// функция собственно со ти овки "пузырьком"
		static void BubbleSort(int[] array)
		{
			// i нам нужна уже не для доступа к массиву, а всего лишь
			// для уменьшения лимита внутреннего цикла
			for (var i = 0; i < array.Length - 1; i++)
			{
				// перебираем массив по j, не доходя до последнего элемента
				// до него мы доберемся через выражение j + 1
				var limit = array.Length - 1 - i;

				for (var j = 0; j < limit; j++)
				{
					// сравниваем текущий и последующий элементы
					// если текущий больше последующего, меняем их местами
					if (array[j] > array[j + 1])
					{
						var temp = array[j + 1];  // обмен значений
						array[j + 1] = array[j];    // двух переменных
						array[j] = temp;          // через третью
					}
				}
			}
		}
	}
}