using System;
using System.Diagnostics;

namespace L09_C04_bubble_sort_calc_time
{
	public class Program
	{
		static void Main()
		{
			var rounds = 10;
			var roundStep = 100_000;

			for (var i = 1; i <= rounds; i++)
			{
				var length = i * roundStep;
				var source = GenerateRandomArray(length);
				var bubbleSorted = (int[])source.Clone();
				var quickSorted = (int[])source.Clone();
				var stopwatch = new Stopwatch();

				stopwatch.Start();
				BubbleSort(bubbleSorted);
				stopwatch.Stop();
				Console.WriteLine($"[Bubble sort], length: {length}, elapsed ms: {stopwatch.ElapsedMilliseconds}");

				stopwatch.Restart();
				Array.Sort(quickSorted);
				stopwatch.Stop();
				Console.WriteLine($"[Quick sort], length: {length}, elapsed ms: {stopwatch.ElapsedMilliseconds}");
			}

			Console.ReadKey();
		}

		// функция создания массива для тестирования сортировки
		static int[] GenerateRandomArray(int length)
		{
			var array = new int[length];
			var random = new Random();

			for (var i = 0; i < array.Length; i++)
			{
				array[i] = random.Next(0, 1_000_0000);
			}

			return array;
		}

		// функция собственно со ти овки "пузырьком"
		static void BubbleSort(int[] array)
		{
			// i нам нужна уже не для доступа к массиву, а всего лишь
			// для уменьшения лимита внутреннего цикла
			for (var i = 0; i < array.Length - 1; i++)
			{
				// перебираем массив по j, не доходя до последнего элемента
				// до него мы доберемся через выражение j + 1
				var limit = array.Length - 1 - i;

				for (var j = 0; j < limit; j++)
				{
					// сравниваем текущий и последующий элементы
					// если текущий больше последующего, меняем их местами
					if (array[j] > array[j + 1])
					{
						var temp = array[j + 1];  // обмен значений
						array[j + 1] = array[j];    // двух переменных
						array[j] = temp;          // через третью
					}
				}
			}
		}
	}
}