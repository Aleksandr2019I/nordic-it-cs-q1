using System;

namespace L09_C01_simple_code_for_ildasm
{
	public class Program
	{
		static void Main()
		{
			int x;
			x = 0;
			x = x + 1;
		}
	}
}