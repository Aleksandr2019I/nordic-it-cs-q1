using System;
using System.Diagnostics;

namespace L09_C05_bubble_vs_dotnet_sort
{
	public class Program
	{
		static void Main()
		{
			var initialArray = GenerateRandomArray(10000);
			var stopwatch = new Stopwatch();

			var bubbleSortedArray = (int[])initialArray.Clone();
			stopwatch.Start();
			BubbleSort(bubbleSortedArray);
			stopwatch.Stop();
			Console.WriteLine($"Bubble sort done in {stopwatch.ElapsedMilliseconds} ms");

			var dotNetSortedArray = (int[])initialArray.Clone();
			stopwatch.Restart();
			Array.Sort(dotNetSortedArray);
			stopwatch.Stop();
			Console.WriteLine($".NET sort done in {stopwatch.ElapsedMilliseconds} ms");
			Console.ReadKey();
		}

		// функция создания массива для тестирования сортировки
		static int[] GenerateRandomArray(int length)
		{
			var array = new int[length];
			var random = new Random();

			for (var i = 0; i < array.Length; i++)
			{
				array[i] = random.Next(0, 1_000_0000);
			}

			return array;
		}

		// функция собственно сортировки "пузырьком"
		static void BubbleSort(int[] arr)
		{
			// i нам нужна уже не для доступа к массиву, а всего лишь
			// для уменьшения лимита внутреннего цикла
			for (var i = 0; i < arr.Length - 1; i++)
			{
				// перебираем массив по j, не доходя до последнего элемента
				// до него мы доберемся через выражение j + 1
				var limit = arr.Length - 1 - i;
				for (var j = 0; j < limit; j++)
				{
					// сравниваем текущий и последующий элементы
					// если текущий больше последующего, меняем их местами
					if (arr[j] > arr[j + 1])
					{
						var temp = arr[j + 1];  // обмен значений
						arr[j + 1] = arr[j];    // двух переменных
						arr[j] = temp;          // через третью
					}
				}
			}
		}
	}
}