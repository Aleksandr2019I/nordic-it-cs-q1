﻿namespace Reminder.Storage
{
	public enum ReminderItemStatus
	{
		Created,
		Ready,
		Sent,
		Failure
	}
}
