﻿namespace L30_C01_working_with_sql_db
{
	// 
	public class CreateProductCommand
	{
	}
}
