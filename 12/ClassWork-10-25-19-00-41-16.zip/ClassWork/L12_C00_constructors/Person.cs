﻿namespace L12_C00_constructors
{
	public class Person
	{
		public string Name { get; set; }

		public string Type => "Regular";
	}
}
