﻿namespace L10_C02_class_fields_pet_SW
{
	public enum PetType : byte
	{
		Undefined = 0,
		Mouse,
		Cat,
		Dog
	}
}