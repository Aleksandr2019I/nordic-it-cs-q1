namespace L17_C05_events_eventargs_final
{
	public enum WorkType
	{
		Work,
		DoNothing
	}
}